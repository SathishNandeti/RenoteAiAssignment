//
//  DocumentsViewController.swift
//  DocumentsTable
//
//

import UIKit

struct Documents: Codable {
    let docName: String
    let createdDate: String
    let isFavourite: Bool
    let docId: String
}



class DocumentsViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var documentsArray = [Documents]()
    
    var favoriteDocumentsArray = [Documents]()

    
    @IBOutlet var documentsTable : UITableView?

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        self.fetchDataFromUrl()
        
    }
    
    
    func fetchDataFromUrl()
    {
        
        let url = URL(string: "https://67ff5bb258f18d7209f0debe.mockapi.io/documents")!
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "GET"  // optional
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let task = session.dataTask(with: request) { data, response, error in
            
            if let error = error {
                print("Error while fetching data:", error)
                return
            }

            guard let data = data else {
                return
            }

            do {
                    let documents = try JSONDecoder().decode([Documents].self, from: data)
                
                self.documentsArray = Array(documents)
                
                DispatchQueue.main.async {
                    self.documentsTable?.reloadData()

                    }

                

                
                
               // print("count: ", self.documentsArray.count)

                
                    for document in documents {
                        
                        if(document.isFavourite == true)
                        {
                            self.favoriteDocumentsArray.append(document)
                            
                            DispatchQueue.main.async {
                                self.documentsTable?.reloadData()
                                }
                        }
                        /*
                        print("docName:", document.docName)
                        print("createdDate:", document.createdDate)
                        print("isFavourite:", document.isFavourite)
                        print("docId:", document.docId)
                        */
                        
                    }
                } catch let jsonError {
                    print("Failed to decode json", jsonError)
                }
            
            print("Fav count: ", self.favoriteDocumentsArray.count)

            
            print("count: ", self.documentsArray.count)

        }
        
        print("count: ", self.documentsArray.count)
        


        
        task.resume()
    }
    
    
    //TABLE View Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        print("count on cell: ", self.documentsArray.count)

        if(favoriteButtionClicked == true)
        {
            return self.favoriteDocumentsArray.count
        }
        else
        {
            return self.documentsArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        if(favoriteButtionClicked == true)
        {
            let document = self.favoriteDocumentsArray[indexPath.row]
            print("docName:", document.docName)
            cell.textLabel?.text = document.docName
            cell.detailTextLabel?.text = document.createdDate
        }
        else
        {
            let document = self.documentsArray[indexPath.row]
            print("docName:", document.docName)
            cell.textLabel?.text = document.docName
            cell.detailTextLabel?.text = document.createdDate
        }
        
        if(darkModeButtionClicked == true)
        {
            cell.contentView.backgroundColor = UIColor.black
            cell.textLabel?.textColor = UIColor.white
            cell.detailTextLabel?.textColor = UIColor.lightGray
        }
        else
        {
            cell.contentView.backgroundColor = UIColor.white
            cell.textLabel?.textColor = UIColor.black
            cell.detailTextLabel?.textColor = UIColor.darkGray

        }
        
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 60
    }
    
    //SWIPE Left to Delete methods
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            // handle delete (by removing the data from your array and updating the tableview)
        }
    }
    
    
    //Swipe Right to Edit Methods
    
    func tableView(_ tableView: UITableView,
                   leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let closeAction = UIContextualAction(style: .normal, title:  "Edit", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            print("OK, Edit Done")
            success(true)
        })
        //closeAction.image = UIImage(named: "tick")
        closeAction.backgroundColor = .purple
        
        return UISwipeActionsConfiguration(actions: [closeAction])
    }

    /*
    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let modifyAction = UIContextualAction(style: .normal, title:  "Favorite", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            print("Favorite Done")
            success(true)
        })
        //modifyAction.image = UIImage(named: "hammer")
        modifyAction.backgroundColor = .blue
        
        return UISwipeActionsConfiguration(actions: [modifyAction])
    }
     */
    
    
    
    @IBOutlet weak var docsSegmentedControl: UISegmentedControl!

    @IBOutlet weak var modesSegmentedControl: UISegmentedControl!
    
    var favoriteButtionClicked = Bool()
    
    var darkModeButtionClicked = Bool()


    
    @IBAction func docsSegmentedControl(sender: AnyObject) {

        if docsSegmentedControl.selectedSegmentIndex == 0
        {
            print("All Docs")
            favoriteButtionClicked = false
            self.documentsTable?.reloadData()
        }
        else
        {
            print("Favorite Docs")
            favoriteButtionClicked = true
            self.documentsTable?.reloadData()
        }
    }
    
    @IBAction func modesSegmentedControl(sender: AnyObject) {

        if modesSegmentedControl.selectedSegmentIndex == 0
        {
            print("Light mode")
            darkModeButtionClicked = false
            self.documentsTable?.reloadData()

        }
        else
        {
            print("Dark mode")
            darkModeButtionClicked = true
            self.documentsTable?.reloadData()
        }
    }
    

    

  
   
}
